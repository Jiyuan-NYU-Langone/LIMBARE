#' @import segmented nlme dplyr ggplot2
#' @export limbare plot.limbare slope
NULL
